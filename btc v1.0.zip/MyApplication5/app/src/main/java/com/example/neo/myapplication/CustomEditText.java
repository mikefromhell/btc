package com.example.neo.myapplication;

import android.content.Context;
import com.example.neo.myapplication.Servo;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.view.inputmethod.InputMethodManager;

import java.io.IOException;

/**
 * Created by neo on 08.06.16.
 */
public class CustomEditText extends EditText {

    Context context;
    public String Name="";
    protected String alfa="0";
    protected String betta="180";

    public CustomEditText(Context context,AttributeSet atr) {
        super(context,atr);
      //  this.context = context;
        Log.d("myLog","Constructor "+context+"  "+atr);


    }






  /*  public  CustomEditText(String str){


        Log.d("myLog",""+str);
    }*/

    @Override
    public boolean onKeyPreIme(int keyCode, KeyEvent event) {
        if ((keyCode == KeyEvent.KEYCODE_BACK)&&(event.getAction()==KeyEvent.ACTION_DOWN)) {



            Log.d("myLog","back "+keyCode+"  "+event );
            if(!examine(this.getText().toString())){
                Log.d("myLog","examine ");

                if(Name.equals("alfa")){
                    this.setText("0");
                    Servo.setAlfa("0");
                    Log.d("myLog","alfa ");
                }
                if(Name.equals("betta")){
                    this.setText("180");
                    Servo.setBetta("180");
                    Log.d("myLog","betta");
                }


            }
            else {
                switch (Name) {
                    case("alfa"):
                    Servo.setAlfa(this.getText().toString());
                     break;
                    case("betta"):
                        Servo.setBetta(this.getText().toString());
                }

                if (Integer.parseInt(Servo.getAlfa()) > Integer.parseInt(Servo.getBetta())) {
                    switch (Name) {
                        case ("alfa"):
                            this.setText("0");
                            Servo.setAlfa("0");
                            break;
                        case ("betta"):
                            this.setText("180");
                            Servo.setBetta("180");
                            break;
                    }

                }


            }
            Servo.setNewProgress(true);
        }
        return false;
    }
    public boolean examine(String str){


        int n=0;
        int str_length=str.length();
        if((str_length<=3)&&(str_length>0)) {
            n = Integer.parseInt(str);

            if(str_length>Integer.toString(n).length()){
                return  false;
            }
        }
        else {
            return false;
        }

        if((n>=0)&&(n<=180)){
            return true;

        }
        else{

            return false;
        }

    }





}