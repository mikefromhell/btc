package com.example.neo.myapplication;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Switch;

import java.math.BigDecimal;
import java.util.ArrayList;

/**
 * Created by neo on 02.07.16.
 */

public class Chart extends View {

    private int mFontColor;
    private int mGridColor;
    private int mTitleColor;
    private int mXLabelColor;
    private int mYLabelColor;

    private String dataType;




    private String mXLabelName;
    private String mYLabelName;
    private String mTitleName;

    private float mMaxWight;
    private float mMaxheight;
    private Paint paintFont;
    private Paint paintGrid;
    private Paint paintAxis;
    private Paint paintChartData;
    private Paint paintHidenExtraPoint;

    private Path pathGridRectangle;
    private Path pathVerticalAxis;
    private Path pathHorisontalAxis;
    private Path pathChartData;
    private Path pathXaxis;
    private Path pathYaxis;
    private Path pathHidenExtraPoint;

    private final float _OFFSET_LEFT=45;
    private final float _OFFSET_RIGHT=30;
    private final float _OFFSET_TOP=50;
    private final float _OFFSET_BOTTOM=55;

    private final float VERTICAL_AXIS_NOMBER=5;
    private final float HORISONTAL_AXIS_NOMBER=5;

    private final int TEXT_X_SIZE=12;
    private final int TEXT_Y_SIZE=12;





    private Canvas canvas;
    private ChartData mdata;

    private float eventDeltaX=0;
    private float eventDeltaY=0;

    private float eventDeltaOneTouchX=0;
    private float eventDeltaOneTouchY=0;



    private float firsteventDeltaX=0;
    private float firsteventDeltaY=0;

    private boolean firsteventMultitouchflag=true;
    private boolean firsteventOnetouchflag=true;

    private boolean flagScale=false;

    private float currentXminValue;
    private float currentYminValue;

    private float currentXmaxValue;
    private float currentYmaxValue;


    private float firsteventOnetouchXValue=0;
    private float firsteventOnetouchYValue=0;

    private float currentXValue;
    private float currentYValue;

    private boolean multiTouchMoveflag=false;
    private boolean oneTouchMoveflag=false;

    private int stepXcount=0;

    private float scaleXcoef=1;
    private float scaleYcoef=1;

    private  ArrayList<String> xAxeVAlue;
    private   ArrayList<String> yAxeVAlue;
    Path testpath;


    public Chart(Context context) {
        super(context);

    }

    public Chart(Context context, AttributeSet attrs) {
        super(context, attrs);


        paintFont=new Paint(Paint.ANTI_ALIAS_FLAG);
        paintGrid=new Paint();
        paintAxis=new Paint();
        paintChartData=new Paint(Paint.ANTI_ALIAS_FLAG);
        paintHidenExtraPoint=new Paint();

        pathGridRectangle=new Path();
        pathVerticalAxis=new Path();
        pathHorisontalAxis=new Path();
        pathChartData=new Path();
        pathXaxis=new Path();

        pathHidenExtraPoint=new Path();
        this.xAxeVAlue = new ArrayList<String>();
        this.yAxeVAlue=new ArrayList<String>();




    }

    public Chart(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);

    }
    @Override
    public void onDraw(Canvas canvas)
    {
        this.canvas=canvas;
        this.setMaxDimnsion();
      //  this.resetMinMaxValue();
        canvas.drawColor(mFontColor);
        setGrid(canvas);
        setChartData();



    }
    @Override
    public boolean onTouchEvent(MotionEvent event) {



        switch(event.getActionMasked()){

            case MotionEvent.ACTION_MOVE:

                if(event.getPointerCount()==1){

                    if(this.firsteventOnetouchflag==true){


                        this.firsteventOnetouchXValue=event.getX();
                        this.firsteventOnetouchYValue=event.getY();
                     //   Log.d("myLog","firstevent one"+this.firsteventOnetouchXValue+"  "+event.getX()+"__"+event.getY());

                        this.firsteventOnetouchflag=false;

                    }

                        this.eventDeltaOneTouchX = this.firsteventOnetouchXValue - event.getX();
                        this.eventDeltaOneTouchY = this.firsteventOnetouchYValue - event.getY();

                   //     Log.d("myLog", "event_Move one=" +"__"+this.firsteventOnetouchXValue+"  "+event.getX()+"  " +this.eventDeltaOneTouchX + "__" + this.eventDeltaOneTouchY);

                        this.firsteventOnetouchXValue = event.getX();
                        this.firsteventOnetouchYValue = event.getY();

                        this.oneTouchMoveflag = true;

                        this.invalidate();


                }

                if(event.getPointerCount()==2){

                    if(this.firsteventMultitouchflag==true){

                        this.firsteventDeltaX=Math.abs(event.getX()-event.getX(1));
                        this.firsteventDeltaY=Math.abs(event.getY()-event.getY(1));
                      //  Log.d("myLog","event first multi");
                        this.firsteventMultitouchflag=false;
                    }

                 //   this.stepXcount++;
                    this.eventDeltaX=this.firsteventDeltaX-Math.abs(event.getX()-event.getX(1));
                    this.eventDeltaY=this.firsteventDeltaY-Math.abs(event.getY()-event.getY(1));

                    this.firsteventDeltaX=Math.abs(event.getX()-event.getX(1));
                    this.firsteventDeltaY=Math.abs(event.getY()-event.getY(1));

                  //  Log.d("myLog","event_Move multi=");

                    if((eventDeltaX!=0)&&(eventDeltaY!=0)){

                        this.flagScale=true;

                        this.multiTouchMoveflag=true;

                        //if(this.stepXcount>2){

                            this.invalidate();
                       //     this.stepXcount=0;
                       // }

                    }

                }
                break;
            case MotionEvent.ACTION_POINTER_UP:

                this.firsteventMultitouchflag=true;
                this.multiTouchMoveflag=false;
               // this.firsteventOnetouchflag=true;


                break;


            case MotionEvent.ACTION_UP:


                 this.firsteventOnetouchflag=true;
                this.oneTouchMoveflag=false;

               // Log.d("myLog","up");

                break;





    }




        return true;
    }

    public void setScaleCoef(){


        this.scaleXcoef=2*(this.currentXmaxValue-this.currentXminValue)/100;
        this.scaleYcoef=2*(this.currentYmaxValue-this.currentYminValue)/100;





    }

    public void setData(){

        Log.d("myLog","size"+mdata.getsize());

    /*    if(mdata.getsize()==1){

            this.currentXminValue=this.mdata.XminValue;
            this.currentYminValue=this.mdata.YminValue;

            this.currentXmaxValue=this.mdata.XmaxValue*2;
            this.currentYmaxValue=this.mdata.YmaxValue*2;



        }else {*/
            this.currentXminValue = this.mdata.XminValue;
            this.currentYminValue = this.mdata.YminValue;

            this.currentXmaxValue = this.mdata.XmaxValue;
            this.currentYmaxValue = this.mdata.YmaxValue;
        this.invalidate();


       // }

    }

    public void setData(ChartData data,String dataType){

        this.mdata=data;
        this.dataType=dataType;

/*        if(mdata.getsize()==1){

            this.currentXminValue=this.mdata.XminValue;
            this.currentYminValue=this.mdata.YminValue;

            this.currentXmaxValue=this.mdata.XmaxValue*2;
            this.currentYmaxValue=this.mdata.YmaxValue*2;



        }else {*/
            this.currentXminValue = this.mdata.XminValue;
            this.currentYminValue = this.mdata.YminValue;

            this.currentXmaxValue = this.mdata.XmaxValue;
            this.currentYmaxValue = this.mdata.YmaxValue;


       // }


    }

    private void setXAxisValue(){

        if(this.flagScale==false) {


            this.xAxeVAlue.clear();
            this.xAxeVAlue.add(String.valueOf(mdata.roundfloat(this.currentXminValue, 2)));

            float deltaX = (mdata.XmaxValue - mdata.XminValue) / (VERTICAL_AXIS_NOMBER + 1);

            for (int i = 1; i <= (int) VERTICAL_AXIS_NOMBER; i++) {
                xAxeVAlue.add(String.valueOf(mdata.roundfloat(mdata.XminValue + deltaX * (float) i, 2)));

            }
            xAxeVAlue.add(String.valueOf(mdata.roundfloat(mdata.XmaxValue, 2)));



        }
        else {

            if(this.multiTouchMoveflag) {

                if (this.eventDeltaX < 0) {

                    if ((this.currentXmaxValue - this.currentXminValue) > 4 * this.scaleXcoef) {

                        this.currentXminValue = this.currentXminValue + this.scaleXcoef;
                        this.currentXmaxValue = this.currentXmaxValue - this.scaleXcoef;

                    }



                }
                if (this.eventDeltaX > 0) {

                    if ((this.currentXmaxValue - this.currentXminValue) < (mdata.XmaxValue - mdata.XminValue)) {

                        if(this.currentXminValue>mdata.XminValue) {

                            this.currentXminValue = this.currentXminValue - this.scaleXcoef;

                        }

                        if(currentXmaxValue<mdata.XmaxValue) {

                            this.currentXmaxValue = this.currentXmaxValue + this.scaleXcoef;
                        }

                    }



                }
            }

            if(this.oneTouchMoveflag) {

                if (this.eventDeltaOneTouchX < 0) {

                    if (this.currentXminValue > mdata.XminValue) {

                        this.currentXminValue = this.currentXminValue - this.scaleXcoef;
                        this.currentXmaxValue = this.currentXmaxValue - this.scaleXcoef;
                    }


                }

                if (this.eventDeltaOneTouchX > 0) {

                    if (this.currentXmaxValue < mdata.XmaxValue) {

                        this.currentXminValue = this.currentXminValue + this.scaleXcoef;
                        this.currentXmaxValue = this.currentXmaxValue + this.scaleXcoef;
                    }


                }
            }
            this.xAxeVAlue.clear();
            this.xAxeVAlue.add(String.valueOf(mdata.roundfloat(this.currentXminValue, 2)));

            float deltaX = (currentXmaxValue - this.currentXminValue) / (VERTICAL_AXIS_NOMBER + 1);

            for (int i = 1; i <= (int) VERTICAL_AXIS_NOMBER; i++) {
                this.xAxeVAlue.add(String.valueOf(mdata.roundfloat(this.currentXminValue + deltaX * (float) i, 2)));

            }
            this.xAxeVAlue.add(String.valueOf(mdata.roundfloat(currentXmaxValue, 2)));






        }
    }
    private void setYAxisVAlue(){

        if(this.flagScale==false) {

            this.yAxeVAlue.clear();


            this.yAxeVAlue.add(String.valueOf(mdata.roundfloat(mdata.YminValue, 2)));

            float deltaY = (mdata.YmaxValue - mdata.YminValue) / (HORISONTAL_AXIS_NOMBER + 1);

            for (int i = 1; i <= (int) HORISONTAL_AXIS_NOMBER; i++) {
                this.yAxeVAlue.add(String.valueOf(mdata.roundfloat(mdata.YminValue + deltaY * (float) i, 2)));

            }
            this.yAxeVAlue.add(String.valueOf(mdata.roundfloat(mdata.YmaxValue, 2)));

            // setYText(yAxeVAlue);

        }
        else  {
            if(this.multiTouchMoveflag) {


                if (this.eventDeltaY < 0) {

                    if ((this.currentYmaxValue - this.currentYminValue) > 4 * this.scaleYcoef) {

                        this.currentYminValue = this.currentYminValue + this.scaleYcoef;
                        this.currentYmaxValue = this.currentYmaxValue - this.scaleYcoef;

                    }

                }
                if (this.eventDeltaY > 0) {

                    if ((this.currentYmaxValue - this.currentYminValue) < (mdata.YmaxValue - mdata.YminValue)) {

                        if(this.currentYminValue>mdata.YminValue){

                            this.currentYminValue = this.currentYminValue - this.scaleYcoef;
                        }

                        if(this.currentYmaxValue<mdata.YmaxValue) {


                            this.currentYmaxValue = this.currentYmaxValue + this.scaleYcoef;
                        }

                    }

                }


            }
            if(this.oneTouchMoveflag) {

                if (this.eventDeltaOneTouchY < 0) {


                    if (this.currentYmaxValue < mdata.YmaxValue) {
                        this.currentYminValue = this.currentYminValue +this.scaleYcoef;
                        this.currentYmaxValue = this.currentYmaxValue + this.scaleYcoef;
                    }


                }

                if (this.eventDeltaOneTouchY > 0) {


                    if (this.currentYminValue > mdata.YminValue) {

                        this.currentYminValue = this.currentYminValue - this.scaleYcoef;
                        this.currentYmaxValue = this.currentYmaxValue - this.scaleYcoef;
                    }


                }
            }



            this.yAxeVAlue.clear();

            this.yAxeVAlue.add(String.valueOf(mdata.roundfloat(currentYminValue, 2)));

            float deltaY = (currentYmaxValue - currentYminValue) / (HORISONTAL_AXIS_NOMBER + 1);

            for (int i = 1; i <= (int) HORISONTAL_AXIS_NOMBER; i++) {
                this.yAxeVAlue.add(String.valueOf(mdata.roundfloat(currentYminValue + deltaY * (float) i, 2)));

            }
            this.yAxeVAlue.add(String.valueOf(mdata.roundfloat(currentYmaxValue, 2)));

            //  setYText(yAxeVAlue);




        }


    }

    private void setChartData(){


        //---------------------------- set chart data

        setScaleCoef();

        //-----------------------------set x Axis data



        setXAxisValue();


        setYAxisVAlue();


        paintChartData.setStrokeWidth(3);
        paintChartData.setStyle(Paint.Style.STROKE);
        paintChartData.setColor(mdata.getdataColor());
        pathChartData.reset();

        float xChart=0;
        float yChart=0;


        float scaleX=(mMaxWight-(_OFFSET_RIGHT+_OFFSET_LEFT))/(this.currentXmaxValue-this.currentXminValue);
        float scaleY=(mMaxheight-(_OFFSET_TOP+_OFFSET_BOTTOM))/(this.currentYmaxValue-this.currentYminValue);

        boolean firstPointFlag=true;

        int visiblePointCount=0;

        boolean currentPointVisible=false;
        boolean earlyPointVisible=false;

        float k=0;
        float b=0;



        for(int i=0;i<mdata.getsize();i++){




          if(  (Float.parseFloat(mdata.getX(i))>=this.currentXminValue)&&(Float.parseFloat(mdata.getX(i))<=this.currentXmaxValue)
                   &&(Float.parseFloat(mdata.getY(i))>=this.currentYminValue) &&(Float.parseFloat(mdata.getY(i))<=this.currentYmaxValue)) {


                visiblePointCount++;

                int firstPoint=i;

                if (this.currentXminValue < 0) {


                    xChart = Float.parseFloat(mdata.getX(i)) * scaleX + _OFFSET_LEFT + (Math.abs(this.currentXminValue) * scaleX);

                } else {

                    xChart = Float.parseFloat(mdata.getX(i)) * scaleX + _OFFSET_LEFT- (Math.abs(this.currentXminValue) * scaleX);

                }
                if (this.currentYminValue < 0) {

                    yChart = mMaxheight - _OFFSET_BOTTOM - (Float.parseFloat(mdata.getY(i)) * scaleY) - (Math.abs(this.currentYminValue) * scaleY);

                } else {

                    yChart = mMaxheight - _OFFSET_BOTTOM - Float.parseFloat(mdata.getY(i)) * scaleY+ (Math.abs(this.currentYminValue) * scaleY);;
                }

                switch (dataType) {

                    case "Point":

                        pathChartData.addCircle(xChart, yChart, 2, Path.Direction.CW);

                         case "Line":
                             if(mdata.getsize()==1){

                                 pathChartData.addCircle(xChart, yChart, 2, Path.Direction.CW);                             }

                        if (firstPointFlag == true) {

                            pathChartData.moveTo(xChart, yChart);



                            firstPointFlag=false;

                        }else {

                            if(earlyPointVisible) {
                                pathChartData.lineTo(xChart, yChart);
                            }
                        }
                }


                if((!earlyPointVisible)&&(i!=0)&&(dataType.equals("Line"))){

                    float xxChart;
                    float yyChart;


                    if (this.currentXminValue < 0) {


                        xxChart = Float.parseFloat(mdata.getX(i-1)) * scaleX + _OFFSET_LEFT + (Math.abs(this.currentXminValue) * scaleX);

                    } else {

                        xxChart = Float.parseFloat(mdata.getX(i-1)) * scaleX + _OFFSET_LEFT- (Math.abs(this.currentXminValue) * scaleX);

                    }
                    if (this.currentYminValue < 0) {

                        yyChart = mMaxheight - _OFFSET_BOTTOM - (Float.parseFloat(mdata.getY(i-1)) * scaleY) - (Math.abs(this.currentYminValue) * scaleY);

                    } else {

                        yyChart = mMaxheight - _OFFSET_BOTTOM - Float.parseFloat(mdata.getY(i-1)) * scaleY+ (Math.abs(this.currentYminValue) * scaleY);;
                    }



                pathChartData.moveTo(xxChart,yyChart);

                pathChartData.lineTo(xChart,yChart);

                }

                earlyPointVisible=true;

            }
           else{

                if((i!=0)&&(earlyPointVisible)&&(dataType.equals("Line"))){

                    float x2Chart=0;
                    float y2Chart=0;

                    pathChartData.moveTo(xChart,yChart);

                    if (this.currentXminValue < 0) {


                        x2Chart = Float.parseFloat(mdata.getX(i)) * scaleX + _OFFSET_LEFT + (Math.abs(this.currentXminValue) * scaleX);

                    } else {

                        x2Chart = Float.parseFloat(mdata.getX(i)) * scaleX + _OFFSET_LEFT- (Math.abs(this.currentXminValue) * scaleX);

                    }
                    if (this.currentYminValue < 0) {

                        y2Chart = mMaxheight - _OFFSET_BOTTOM - (Float.parseFloat(mdata.getY(i)) * scaleY) - (Math.abs(this.currentYminValue) * scaleY);

                    } else {

                        y2Chart = mMaxheight - _OFFSET_BOTTOM - Float.parseFloat(mdata.getY(i)) * scaleY+ (Math.abs(this.currentYminValue) * scaleY);;
                    }





                    Log.d("myLog","line"+x2Chart+"  "+y2Chart);
                    pathChartData.lineTo(x2Chart,y2Chart);
                }

                earlyPointVisible=false;

            }



        }

        if((visiblePointCount==0)&&(dataType.equals("Line"))){
            xChart=0;
            yChart=0;

            for(int i=0;i<mdata.getsize();i++) {

                if (this.currentXminValue < 0) {


                    xChart = Float.parseFloat(mdata.getX(i)) * scaleX + _OFFSET_LEFT + (Math.abs(this.currentXminValue) * scaleX);

                } else {

                    xChart = Float.parseFloat(mdata.getX(i)) * scaleX + _OFFSET_LEFT- (Math.abs(this.currentXminValue) * scaleX);

                }
                if (this.currentYminValue < 0) {

                    yChart = mMaxheight - _OFFSET_BOTTOM - (Float.parseFloat(mdata.getY(i)) * scaleY) - (Math.abs(this.currentYminValue) * scaleY);

                } else {

                    yChart = mMaxheight - _OFFSET_BOTTOM - Float.parseFloat(mdata.getY(i)) * scaleY+ (Math.abs(this.currentYminValue) * scaleY);;
                }

                   pathChartData.lineTo(xChart,yChart);



            }



            }
        canvas.drawPath(pathChartData,paintChartData);

        setPathHidnExtraPoint();
        setXText(this.xAxeVAlue);
        setYText(this.yAxeVAlue);


    }

    private void setPathHidnExtraPoint(){

        paintHidenExtraPoint.setStyle(Paint.Style.FILL);
        paintHidenExtraPoint.setColor(mFontColor);
        paintHidenExtraPoint.setStrokeWidth(1);

        pathHidenExtraPoint.reset();
        pathHidenExtraPoint.addRect(0,0,mMaxWight,_OFFSET_TOP-2, Path.Direction.CW);
        pathHidenExtraPoint.addRect(0,0,_OFFSET_LEFT-2,mMaxheight,Path.Direction.CW);
        pathHidenExtraPoint.addRect(mMaxWight-_OFFSET_RIGHT+2,0,mMaxWight,mMaxheight, Path.Direction.CW);
        pathHidenExtraPoint.addRect(0,mMaxheight-_OFFSET_BOTTOM+2,mMaxWight,mMaxheight, Path.Direction.CW);
        canvas.drawPath(pathHidenExtraPoint,paintHidenExtraPoint);
    }

    private void setGrid(Canvas canvas){

        paintGrid.setStrokeWidth(3);
        paintGrid.setStyle(Paint.Style.STROKE);
        paintGrid.setColor(Color.BLACK);

        paintAxis.setStrokeWidth(1);
        paintAxis.setColor(Color.BLACK);
        paintAxis.setStyle(Paint.Style.STROKE);
      //  paintAxis.setPathEffect(new DashPathEffect(new float[]{100,5},10));



        //-----------------------------------------------Draw rectangle
        pathGridRectangle.reset();
        pathGridRectangle.moveTo(_OFFSET_LEFT,_OFFSET_TOP);
        pathGridRectangle.addRect(_OFFSET_LEFT,_OFFSET_TOP,mMaxWight-_OFFSET_RIGHT,mMaxheight-_OFFSET_BOTTOM,Path.Direction.CW);

       //-----------------------------------------------Draw Vetical axis

        float verticalGap=(mMaxWight-_OFFSET_LEFT-_OFFSET_RIGHT)/(VERTICAL_AXIS_NOMBER+1);

        pathVerticalAxis.reset();

        for(int i=1;i<VERTICAL_AXIS_NOMBER+1;i++) {

            pathVerticalAxis.moveTo(_OFFSET_LEFT + verticalGap*(float)i, _OFFSET_TOP);
            pathVerticalAxis.lineTo(verticalGap*(float)i + _OFFSET_LEFT, mMaxheight - _OFFSET_BOTTOM);
        }

        //----------------------------------------------Draw Horisontal axis

       float horisontalGap=(mMaxheight-_OFFSET_TOP-_OFFSET_BOTTOM)/(HORISONTAL_AXIS_NOMBER+1);

        pathHorisontalAxis.reset();

        for(int i=1;i<HORISONTAL_AXIS_NOMBER+1;i++) {

            pathHorisontalAxis.moveTo(_OFFSET_LEFT,_OFFSET_TOP+horisontalGap*(float)i);
            pathHorisontalAxis.lineTo(mMaxWight-_OFFSET_RIGHT,_OFFSET_TOP+horisontalGap*(float)i);
        }

        //----------------------------------------------
        canvas.drawPath(pathGridRectangle, paintGrid);
        canvas.drawPath(pathVerticalAxis,paintAxis);
        canvas.drawPath(pathHorisontalAxis,paintAxis);


    }

    private void setXText(ArrayList<String> xtext){



        float wight=0;
        float X=0;
        float Y=0;
        float verticalGap=(mMaxWight-_OFFSET_LEFT-_OFFSET_RIGHT)/(VERTICAL_AXIS_NOMBER+1);


        paintFont.setTextSize(TEXT_X_SIZE);
        paintFont.setStyle(Paint.Style.STROKE);



        Y= (float) (mMaxheight-_OFFSET_BOTTOM+(float)(TEXT_X_SIZE)*1.5);

        for(int i=0;i<VERTICAL_AXIS_NOMBER+2;i++) {

            wight=paintFont.measureText(xtext.get(i));
            X=(_OFFSET_LEFT-wight/2)+verticalGap*i;

            canvas.drawText(xtext.get(i), X, Y, paintFont);
        }




    }

    private void setYText(ArrayList<String> ytext){


        float wight=0;
        float X=0;
        float Y=0;
        float horisontalGap=(mMaxheight-_OFFSET_TOP-_OFFSET_BOTTOM)/(HORISONTAL_AXIS_NOMBER+1);


        paintFont.setTextSize(TEXT_Y_SIZE);
        paintFont.setStyle(Paint.Style.STROKE);




        for(int i=0;i<HORISONTAL_AXIS_NOMBER+2;i++) {
            wight=paintFont.measureText(ytext.get(i));
            X=_OFFSET_LEFT-wight-3;

           // Y=_OFFSET_TOP+(TEXT_Y_SIZE/2)+horisontalGap*i;
            Y=mMaxheight-_OFFSET_BOTTOM-horisontalGap*i;

            canvas.drawText(ytext.get(i), X, Y, paintFont);
        }




    }

    private void setMaxDimnsion(){

        this.mMaxheight=(float)this.getHeight();
        this.mMaxWight=(float)this.getWidth();

    }
    public void setmFontColor(int alpha, int red, int green,int blue){

        mFontColor=Color.argb(alpha, red, green, blue);

    }
    public void setmGridColor(int alpha, int red, int green,int blue){

        mGridColor=Color.argb(alpha, red, green, blue);

    }
    public void setmTitleColor(int alpha, int red, int green,int blue){

        mTitleColor=Color.argb(alpha, red, green, blue);

    }
    public void setmXLabelColor(int alpha, int red, int green,int blue){

        mXLabelColor=Color.argb(alpha, red, green, blue);

    }
    public void setmYLabelColor(int alpha, int red, int green,int blue){

        mYLabelColor=Color.argb(alpha, red, green, blue);

    }





}