package com.example.neo.myapplication;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.util.Log;
import android.widget.Toast;

import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.UUID;


public class ConnectThread extends Thread {


    private  BluetoothSocket mmSocket;
    private final BluetoothDevice mmDevice;
    private final BluetoothAdapter mBluetoothAdapter;

    OutputStream outStream ;
    final String LOG_TAG = "myLogs";


    public ConnectThread(BluetoothDevice device, BluetoothAdapter mmBluetoothAdapter) {

      mmSocket = null;
        mmDevice = device;
        mBluetoothAdapter=mmBluetoothAdapter;

        try{

            Log.d("myLogs", "in thread");


            Method m = mmDevice.getClass().getMethod(
                    "createRfcommSocket", new Class[] {int.class});

            mmSocket = (BluetoothSocket) m.invoke(mmDevice, 1);

            mBluetoothAdapter.cancelDiscovery();
            mmSocket.connect();

        } catch (IOException e) {
            Log.d("myLogs", ""+e);
        } catch (SecurityException e) {
            Log.d("myLogs", ""+e);
        } catch (NoSuchMethodException e) {
            Log.d("myLogs", ""+e);
        } catch (IllegalArgumentException e) {
            Log.d("myLogs", ""+e);
        } catch (IllegalAccessException e) {
            Log.d("myLogs", ""+e);
        } catch (InvocationTargetException e) {
            Log.d("myLogs", ""+e);
        }


        try {
            OutputStream outStream = mmSocket.getOutputStream();
            String mes="Hello\n";
            byte[] measange=mes.getBytes();
            for(int i=1;i<3;i++) {
                outStream.write(measange);
            }
        } catch (IOException e){}


    }

    public void run() {

    }

    public void cancel() {
        try {
            mmSocket.close();
        } catch (IOException e) { }
    }

    public  void send()  {

        try {
            outStream.write(11);
        } catch (IOException e) {
            Log.d(LOG_TAG,"error write:"+e);
        }
    }



}