package com.example.neo.myapplication;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.Color;

import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Timer;
import java.util.TimerTask;


import java.util.ArrayList;
import java.util.Arrays;


public class Termo extends Activity {

    Chart chart;
    ChartData data;

    EditText timeText;

    private ServiceConnection sConn;
    private Handler h;
    private static MyService myService;
    private static boolean connected=false;
    private int count=0;

    private String buff=new String();
    private String datafromBluetooth="";

    private Timer mTimer;
    private MyTimerTask mMyTimerTask;

  //  private String mtimeDelay="1000";

    private float ADC_Accuracy=1024;
    private float DC_Power= (float) 3.46;
    private float Ref_DC= (float) 3.46;
    private float Resistance_R=10;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_termo);

        timeText=(EditText) findViewById(R.id.timeDelay);





        Intent intent = new Intent(this, MyService.class);

        h = new Handler() {
            public void handleMessage(android.os.Message msg) {

                int arg1=0;
                boolean numberformatexception=true;
              //  buff= (String) msg.obj;

                arg1=msg.arg1;
                Log.d("myLog","Termo handler buff "+buff );
;

                if(arg1!=10) {

                    buff=Character.toString((char) arg1);
                    datafromBluetooth = datafromBluetooth + buff;

                    Log.d("myLog","Termo handler if "+datafromBluetooth);
                }
                else
                {
                    Log.d("myLog","Termo handler else ");



                       try {

                           Float.parseFloat(datafromBluetooth);

                       }catch (NumberFormatException e){


                           numberformatexception=false;
                       }

                        if(numberformatexception){

                        count++;
                            Log.d("myLog","data temper"+datafromBluetooth);

                            float u2,Resistance_R_RT,Temperaure_termo;

                            u2=(Float.parseFloat(datafromBluetooth)*Ref_DC)/ADC_Accuracy;

                            Resistance_R_RT=((u2*Resistance_R)/(DC_Power-u2))/10;

                            Temperaure_termo=(float) (1/(Math.log(Resistance_R_RT)/4050.0+1/(25.0+273.15))-273.15);


                            data.AddChartData(String.valueOf(count),Float.toHexString(Temperaure_termo));
                        chart.setData();

                        }

                    //}

                    datafromBluetooth="";
                }





            }

        };
        sConn = new ServiceConnection() {

            public void onServiceConnected(ComponentName name, IBinder binder) {

                myService = ((MyService.MyBinder) binder).getService();
                myService.setNameActivity("Termo");
                myService.read(h);



            }



            public void onServiceDisconnected(ComponentName name) {

            }
        };

        if(isMyServiceRunning(MyService.class)){

            Toast.makeText(getApplicationContext(), "CONNECTED", Toast.LENGTH_LONG).show();

            bindService(intent,sConn,0);

            connected=true;
        }
        else {
            Toast.makeText(getApplicationContext(), "NO CONNECTION", Toast.LENGTH_LONG).show();
            connected=false;
        }



       chart=(Chart) findViewById(R.id.chart);
        chart.setmFontColor(255,191,191,191);

        ArrayList<String> x=new ArrayList<String>();
        ArrayList<String> y=new ArrayList<String>();

        for(int i=-64;i<64;i++){
            float xx= i*(float) 0.1;
            float yy= (float) Math.cos((double)xx);
           // float yy=xx;
            x.add(String.valueOf(xx));
            y.add(String.valueOf(yy));

        }
        //data=new ChartData(x,y);
        data=new ChartData();



        data.setdataColor(255,0,0,255);
        chart.setData(data,"Line");
      //  data.AddChartData("10","10");
     //   chart.setData();
      //  data.AddChartData("12","-10");

       // chart.setData();




    }


    public void onClickSendBluetooth(View v){

      //timeText.getText().toString();

       if (mTimer != null) {
            mTimer.cancel();
           mTimer.purge();

        }
        mTimer = new Timer();
        mMyTimerTask = new MyTimerTask();


       mTimer.schedule(mMyTimerTask,0,Long.parseLong(timeText.getText().toString()));

       // myService.send("temper\r");
      //  Log.d("myLog","send termo ");

    }

    private boolean isMyServiceRunning(Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }


    class MyTimerTask extends TimerTask{


        @Override
        public void run() {

            runOnUiThread(new Runnable() {

                @Override
                public void run() {

                    myService.send("temper\r");

                }
            });
        }
    }


    protected void onDestroy(){

        if(connected){

            unbindService(sConn);
        }

        if (mTimer != null) {
            mTimer.cancel();
            mTimer = null;
        }
        super.onDestroy();
    }
}
