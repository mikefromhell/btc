package com.example.neo.myapplication;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.Rect;
import android.os.IBinder;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;

import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class Servo extends Activity {

    private static CustomEditText alfa;//=new CustomEditText(this, com.android.internal.R.attr.editTextStyle);
    private static CustomEditText betta;
  //  String alfa_value,betta_value;
    private static SeekBar angle;
    private static TextView current;
    protected static float SeekBar_minvalue=0;
    protected static float SeekBar_maxvalue=180;
     protected static String alfa_value="0";
    protected static String betta_value="180";
    private static boolean connected=false;
    ServiceConnection sConn;
    private static MyService myService;



    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_servo);

        Context context=this;

        //AttributeSet atr=this.ob

        Log.d("myLog", "activity "+context);

        alfa=(CustomEditText)findViewById(R.id.Servo_Text_alfa);
        betta=(CustomEditText)findViewById(R.id.Servo_Text_betta);
        angle=(SeekBar) findViewById(R.id.Servo_angle);
        current=(TextView)findViewById(R.id.Servo_current_value) ;
     //   editText = (CustomEditText) findViewById(R.id.CEditText);
        alfa.Name="alfa";
        betta.Name="betta";
        current.setText(Integer.toString(angle.getProgress()));
        Intent intent = new Intent(this, MyService.class);
        sConn = new ServiceConnection() {

            public void onServiceConnected(ComponentName name, IBinder binder) {

                myService = ((MyService.MyBinder) binder).getService();



            }



            public void onServiceDisconnected(ComponentName name) {

            }
        };

        if(isMyServiceRunning(MyService.class)){

            Toast.makeText(getApplicationContext(), "CONNECTED", Toast.LENGTH_LONG).show();
            bindService(intent,sConn,0);
            connected=true;
        }
        else {
            Toast.makeText(getApplicationContext(), "NO CONNECTION", Toast.LENGTH_LONG).show();
            connected=false;
        }



        alfa.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int actionId, KeyEvent event) {
                Log.d("myLog", "alfa Action ID = " + actionId + "KeyEvent = " + event);

                    if((event.getKeyCode()==KeyEvent.KEYCODE_ENTER)&&(event.getAction()==KeyEvent.ACTION_DOWN)) {

                        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                        imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
                        if (!alfa.examine(alfa.getText().toString())) {
                            Toast.makeText(getApplicationContext(), "Error! Value must be from 0 to 180", Toast.LENGTH_LONG).show();
                            alfa.setText("0");
                        }
                        else if  (Integer.parseInt(betta.getText().toString()) < Integer.parseInt(alfa.getText().toString())) {
                            Toast.makeText(getApplicationContext(), "Error! Betta must be large then Alfa", Toast.LENGTH_LONG).show();
                            alfa.setText("0");
                        }
                        else{
                      //      setRange(v);
                        }

                        setAlfa(alfa.getText().toString());

                        current.setText(Integer.toString(setNewProgress(false)));


                    }

                return false;
            }
        });
        betta.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int actionId, KeyEvent event) {
                Log.d("myLog", "betta Action ID = " + actionId + "KeyEvent = " + event);
                if((event.getKeyCode()==KeyEvent.KEYCODE_ENTER)&&(event.getAction()==KeyEvent.ACTION_DOWN)) {

                    InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
                    if (!betta.examine(betta.getText().toString())) {
                        Toast.makeText(getApplicationContext(), "Error! Value must  be from 0 to 180", Toast.LENGTH_LONG).show();
                        betta.setText("180");
                    }
                    else if (Integer.parseInt(betta.getText().toString()) < Integer.parseInt(alfa.getText().toString())) {
                        Toast.makeText(getApplicationContext(), "Error! Betta must be large then Alfa", Toast.LENGTH_LONG).show();
                        betta.setText("180");
                    }

                    setBetta(betta.getText().toString());
                    current.setText(Integer.toString(setNewProgress(false)));



                }

                return false;
            }
        });


          SeekBar.OnSeekBarChangeListener seekBarChangeListener =
                new SeekBar.OnSeekBarChangeListener() {
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress,
                                                  boolean fromUser) {
                        // TODO Auto-generated method stub
                        Log.d("myLog",alfa.getText().toString()+" "+betta.getText().toString());
                        if(!(alfa.getText().toString().equals(""))&&!(betta.getText().toString().equals(""))) {
                            Log.d("myLog","if");
                         //   SeekBar_minvalue = Float.parseFloat(alfa.getText().toString());
                          //  SeekBar_maxvalue = Float.parseFloat(betta.getText().toString());

                          //  int c = (int) (SeekBar_minvalue + ((SeekBar_maxvalue - SeekBar_minvalue) * (((float) progress) / ((float) angle.getMax()))));
                           // current.setText(Integer.toString(setNewProgress(false)));
                            setNewProgress(true);
                          //  if(connected){
                          //      myService.send(current.getText().toString()+"\n");
                          //  }
                        }
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {
                        // TODO Auto-generated method stub
                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                        // TODO Auto-generated method stub

                    }
                };
        angle.setOnSeekBarChangeListener(seekBarChangeListener);
    }

    public void  Clear(View v){

        Log.d("myLog","view="+v);
        switch (v.getId()) {
            case (R.id.Servo_Text_alfa):
                alfa_value=alfa.getText().toString();
                alfa.setText("");

                break;
            case (R.id.Servo_Text_betta):
                betta_value=betta.getText().toString();
                betta.setText("");

                break;
        }

    }


    public static String getAlfa(){
       return alfa_value;
    }
    public static String getBetta(){
        return betta_value;
    }
    public static void setAlfa(String alfa){
        alfa_value=alfa;
    }
    public static void setBetta(String betta){
        betta_value=betta;
    }
    public  static int setNewProgress(boolean setProgress){

        SeekBar_minvalue = Float.parseFloat(alfa.getText().toString());
        SeekBar_maxvalue = Float.parseFloat(betta.getText().toString());

        int c = (int) (SeekBar_minvalue + ((SeekBar_maxvalue - SeekBar_minvalue) * (((float) angle.getProgress()) / ((float) angle.getMax()))));

        if(setProgress){
            current.setText(Integer.toString(c));

        }
        if(connected){

           myService.send("servo "+Integer.toString(c*10+700)+"\r");
        }
        return c;
    }
    private boolean isMyServiceRunning(Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }
    protected void onDestroy(){

        if(connected){

        unbindService(sConn);
        }
        super.onDestroy();
    }



}
