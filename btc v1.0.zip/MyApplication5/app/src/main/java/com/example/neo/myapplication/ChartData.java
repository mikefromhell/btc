package com.example.neo.myapplication;

import android.graphics.Color;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by neo on 07.07.16.
 */
public class ChartData {

    private ArrayList<String> X;
    private ArrayList<String> Y;
    private int dataColor;

    
    public float XmaxValue;
    public float YmaxValue;
    public float XminValue;
    public float YminValue;




    public ChartData(ArrayList<String> x, ArrayList<String> y) {

        if (x.size() == y.size()) {
            X = new ArrayList<String>();
            Y = new ArrayList<String>();
            X = x;
            Y = y;
                                  
        } 
        
       XmaxValue=this.getXmaxValue();
        YmaxValue=this.getYmaxValue();
        XminValue=this.getXminValue();
        YminValue=this.getYminValue();
        
        
    }
    public ChartData() {
        X = new ArrayList<String>();
        Y = new ArrayList<String>();


    }

    public int getdataColor(){

      return this.dataColor;

    }

    public void setdataColor(int alpha, int red, int green,int blue){

        this.dataColor= Color.argb(alpha, red, green, blue);

    }
    public int getsize(){

        return X.size();
    }
  /*  public int getYsize(){

        return Y.size();
    }*/

    public String getX(int number){

        return this.X.get(number);
    }

    public String getY(int number){

        return this.Y.get(number);
    }

    public void AddChartData(String x, String y) {

        X.add(x);
        Y.add(y);

        XmaxValue=this.getXmaxValue();
        YmaxValue=this.getYmaxValue();
        XminValue=this.getXminValue();
        YminValue=this.getYminValue();

        if(this.X.size()==1){


            XmaxValue= Float.parseFloat(X.get(0))+10;
            YmaxValue=Float.parseFloat(Y.get(0))+10;

            XminValue=Float.parseFloat(X.get(0))-10;
            YminValue=Float.parseFloat(Y.get(0))-10;

        }

    }

    public float roundfloat(float number, int scale) {
        int pow = 10;
        for (int i = 1; i < scale; i++)
            pow *= 10;
        float tmp = number * pow;
        return (float) (int) ((tmp - (int) tmp) >= 0.5 ? tmp + 1 : tmp) / pow;
    }

    private float getXmaxValue() {

        int currentMaxIndex = 0;
        float currentMax = Float.parseFloat(X.get(0));

        for (int i = 1; i < X.size(); i++) {

            if (Float.parseFloat(X.get(i)) > currentMax) {

                currentMax = Float.parseFloat(X.get(i));
            }


        }
        
        return currentMax; 

    }
    private float getYmaxValue() {

        int currentMaxIndex = 0;
        float currentMax = Float.parseFloat(Y.get(0));

        for (int i = 1; i < Y.size(); i++) {

            if (Float.parseFloat(Y.get(i)) > currentMax) {

                currentMax = Float.parseFloat(Y.get(i));
            }


        }

        return currentMax;

    }
    private float getXminValue() {


        float currentMin = Float.parseFloat(X.get(0));

        for (int i = 1; i < X.size(); i++) {

            if (Float.parseFloat(X.get(i)) < currentMin) {

                currentMin = Float.parseFloat(X.get(i));
            }


        }

        return currentMin;

    }

    private float getYminValue() {

       
        float currentMin = Float.parseFloat(Y.get(0));

        for (int i = 1; i < Y.size(); i++) {

            if (Float.parseFloat(Y.get(i)) < currentMin) {

                currentMin = Float.parseFloat(Y.get(i));
            }


        }

        return currentMin;

    }
    
}