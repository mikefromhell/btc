package com.example.neo.myapplication;

import android.app.Activity;
import android.app.ActivityManager;
import android.bluetooth.BluetoothAdapter;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.Color;
import android.os.IBinder;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.text.Html;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.method.ScrollingMovementMethod;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Handler;


import java.util.List;

public class Main2Activity extends Activity {

    Button rx_clear;
    Button send;
    TextView rx_console;
    EditText tx_console;
    CheckBox _LF;
    CheckBox _CR;

    final String LOG_TAG = "myLogs";
    ServiceConnection sConn;
    MyService myService;
    Intent intent;
    Handler h;
    SpannableStringBuilder r_text;
    ForegroundColorSpan style;
     boolean connected=false;

    String buf=new String();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        rx_clear=(Button)findViewById(R.id.rx_clear);
        rx_console=(TextView) findViewById(R.id.RxConsole);
        tx_console=(EditText)findViewById(R.id.TxConsole) ;
        _LF=(CheckBox)findViewById((R.id.check_lf));
        _CR=(CheckBox)findViewById((R.id.check_cr));

        send=(Button)findViewById(R.id.send);


        rx_console.setMovementMethod(new ScrollingMovementMethod());

        h = new Handler() {
            public void handleMessage(android.os.Message msg) {

                buf= (String) msg.obj;


                Log.d(LOG_TAG,"handler "+buf);
                final int scrollAmount = rx_console.getLayout().getLineTop(rx_console.getLineCount()) - rx_console.getHeight();
                // if there is no need to scroll, scrollAmount will be <=0
                if (scrollAmount > 0)
                    rx_console.scrollTo(0, scrollAmount);
                else
                    rx_console.scrollTo(0, 0);

                rx_console.append(buf);
            }
        };

        intent = new Intent(this, MyService.class);
        sConn = new ServiceConnection() {

            public void onServiceConnected(ComponentName name, IBinder binder) {

                myService = ((MyService.MyBinder) binder).getService();
                //myService.setHandler(h);
                myService.setNameActivity("Terminal");
                myService.read(h);


            }



            public void onServiceDisconnected(ComponentName name) {

            }
        };



        if(isMyServiceRunning(MyService.class)){
            Log.d(LOG_TAG,"Service start");
            Toast.makeText(getApplicationContext(), "CONNECTED", Toast.LENGTH_LONG).show();
            bindService(intent,sConn,0);
            connected=true;
        }
        else {
            Log.d(LOG_TAG, "Service stop");
            Toast.makeText(getApplicationContext(), "NO CONNECTION", Toast.LENGTH_LONG).show();
            connected=false;
        }
//--------------------------------------------------------------------------------
        final View.OnClickListener clear = new View.OnClickListener() {
            public void onClick(View v) {
                // do something when the button is clicked
               // rx_console.setText("");

                rx_console.setText("");

            }
        };
        rx_clear.setOnClickListener(clear);
        //-----------------------------------------------------------------------------
        final View.OnClickListener Txsend = new View.OnClickListener() {
            public void onClick(View v) {
                // do something when the button is clicked
                if (connected) {
                    if (tx_console.getText().length() > 0) {

                        String add = "";
                        if (_CR.isChecked()) {
                            add = add + "\r";
                        }
                            if (_LF.isChecked()) {
                            add = add + "\n";
                             }

                        myService.send(tx_console.getText().toString() + add);


                        final int scrollAmount = rx_console.getLayout().getLineTop(rx_console.getLineCount()) - rx_console.getHeight();
                        // if there is no need to scroll, scrollAmount will be <=0
                        if (scrollAmount > 0)
                            rx_console.scrollTo(0, scrollAmount);
                        else
                            rx_console.scrollTo(0, 0);

                        String rx_tet = tx_console.getText().toString();

                        rx_console.append(Html.fromHtml("<font color=#ff0000>Tx: </font><font color=#00ff00>" + rx_tet + "</font>"));
                        rx_console.append("\n");
                        tx_console.setText("");
                    }
                }
                else{
                    Toast.makeText(getApplicationContext(), "NO CONNECTION", Toast.LENGTH_LONG).show();
                }
            }
            };
            send.setOnClickListener(Txsend);

    }
    private boolean isMyServiceRunning(Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }
    protected void onDestroy(){
        if(myService!=null){

             myService.setNameActivity("");
                 unbindService(sConn);
        }
        super.onDestroy();
    }
}
