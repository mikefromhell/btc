package com.example.neo.myapplication;

import android.app.Activity;
import android.content.Intent;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.view.View.OnClickListener;
import android.view.Menu;
import android.content.Context;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;


public class MainActivity extends Activity {

    Button button;

    TextView mytext;
    Intent intent,intent2,intent3;


    public void metod(View view) {
        // действия, совершаемые после нажатия на кнопку

        startActivity(intent2);

    }

    public void startTermo(View view) {
        // действия, совершаемые после нажатия на кнопку

        startActivity(intent3);

    }

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button=(Button)findViewById(R.id.button);


        mytext=(TextView)findViewById(R.id.text);

        intent2 = new Intent(this, Main2Activity.class);
        intent3=new Intent(this,Termo.class);


        final OnClickListener mCorkyListener = new OnClickListener() {
            public void onClick(View v) {
                // do something when the button is clicked
              //  mytext.setText("click");

                startActivity(intent);
            }
        };
         intent = new Intent(this, Servo.class);
        button.setOnClickListener(mCorkyListener);










} public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);


        menu.add(0,1,1,"Settings");
        menu.add(0,2,2,"Close");
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
      //  TextView headerView = (TextView) findViewById(R.id.header);
        switch(id){
            case 1: {
                //Intent intent = new Intent(Settings.ACTION_BLUETOOTH_SETTINGS);
                Intent intent = new Intent(this, Main3Activity.class);

                startActivity(intent);

                return true;
            }
            case 2:
                mytext.setText("Close");
                return true;

        }
        return super.onOptionsItemSelected(item);
    }

    protected void onDestroy() {
        super.onDestroy();
        // The activity is about to be destroyed.
        stopService(new Intent(this,MyService.class));
    }

}