package com.example.neo.myapplication;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.ToggleButton;
import android.util.Log;

public class Main3Activity extends Activity {

    final String LOG_TAG = "myLogs";

    MyService myService;
    ServiceConnection sConn;
    TextView text;
    ToggleButton bt_statusBT;
    ArrayAdapter<String> btdevicelist;
    ListView  btlist;
    BluetoothDevice mydevice;
    BluetoothAdapter myBTadapter=BluetoothAdapter.getDefaultAdapter();
    BroadcastReceiver mReceiver;
    Intent intent;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        text=(TextView)findViewById(R.id.textView) ;
        bt_statusBT=(ToggleButton)findViewById(R.id.bt_BTStatus);
        btlist=(ListView)findViewById(R.id.listView);

        btdevicelist = new ArrayAdapter<>(this,R.layout.my_item);
        btlist.setChoiceMode(ListView.FOCUSABLES_TOUCH_MODE);

       intent=new Intent(this, MyService.class);
      //  startService(intent);

        if(myBTadapter.isEnabled()){
            bt_statusBT.setChecked(true);

        }
        else {
            bt_statusBT.setChecked(false);
        }

        mReceiver = new BroadcastReceiver() {
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                // When discovery finds a device
                if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                    // Get the BluetoothDevice object from the Intent
                    mydevice = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);

                    btdevicelist.add(mydevice.getName() + "\n" + mydevice.getAddress());
                    btlist.setAdapter(btdevicelist);
                }
            }
        };
// Register the BroadcastReceive
        IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
        registerReceiver(mReceiver, filter); // Don't forget to unregister during onDestroy

        btlist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                text.setText(""+position+"/"+id+""+btdevicelist.getItem(position));
                intent.putExtra("mac",btdevicelist.getItem(position));

                Log.d(LOG_TAG, "Start service");

                startService(intent);
            }
        });



        sConn = new ServiceConnection() {

            public void onServiceConnected(ComponentName name, IBinder binder) {

                myService = ((MyService.MyBinder) binder).getService();


            }



            public void onServiceDisconnected(ComponentName name) {

            }
        };



    }

    public void onClickbtscan(View v){


        myBTadapter.startDiscovery();

    }
    public void onClick_BtON_OFF(View v){

        if(bt_statusBT.isChecked()){

            startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE),0);


        }
        else {
            myBTadapter.disable();
            stopService(new Intent(this, MyService.class));
        }


    }

   protected void onActivityResult(int requestCode, int resultCode, Intent data) {

       if(resultCode==0){
           bt_statusBT.setChecked(false);


       }


    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(mReceiver);
        if (myBTadapter.isDiscovering()) {
            myBTadapter.cancelDiscovery();
        }

    }
}
