package com.example.neo.myapplication;

import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;

import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.widget.ArrayAdapter;
import android.util.Log;
import com.example.neo.myapplication.ConnectThread;


import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.UUID;
import java.util.logging.Logger;
import com.example.neo.myapplication.CustomEditText;

public class MyService extends Service {

    final String LOG_TAG = "myLogs";

    public MyService() {
    }
    public String[] mac0;

    ConnectThread flow;
    BluetoothDevice device;
    MyBinder binder = new MyBinder();
    BluetoothAdapter myBTadapter;
    OutputStream outStream;
    InputStream  inputStream;
    private  String NameActivity="";

    BluetoothSocket mmSocket;
    Thread t;
    Handler h;
    public volatile boolean thread_run=true;

    String buf=new String();



   //-----------------------------------------------------------------------------------------
    public int onStartCommand(Intent intent, int flags, int startId) {


        String mac = intent.getStringExtra("mac");
        mac0 = mac.trim().split("\n");

        myBTadapter=BluetoothAdapter.getDefaultAdapter();

        device = myBTadapter.getRemoteDevice(mac0[1]);
        Log.d(LOG_TAG, "Start service OK: "+mac0[1]);



        try{

            Log.d("myLogs", "in thread");


            Method m = device.getClass().getMethod(
                    "createRfcommSocket", new Class[] {int.class});

            mmSocket = (BluetoothSocket) m.invoke(device, 1);

            myBTadapter.cancelDiscovery();
            mmSocket.connect();

        } catch (IOException e) {
            Log.d("myLogs", ""+e);
        } catch (SecurityException e) {
            Log.d("myLogs", ""+e);
        } catch (NoSuchMethodException e) {
            Log.d("myLogs", ""+e);
        } catch (IllegalArgumentException e) {
            Log.d("myLogs", ""+e);
        } catch (IllegalAccessException e) {
            Log.d("myLogs", ""+e);
        } catch (InvocationTargetException e) {
            Log.d("myLogs", ""+e);
        }


        try {
            outStream = mmSocket.getOutputStream();
           // inputStream=mmSocket.getInputStream();

        } catch (IOException e){}

      //  read();
        Log.d(LOG_TAG, "delay");

        return START_NOT_STICKY;
    }
    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        return binder;
    }
    @Override
    public boolean onUnbind(Intent intent) {
        Log.d("myLog","unbind "+NameActivity);
     //   NameActivity="";
        return super.onUnbind(intent);
    }
//--------------------------------------------------------------------------------------------------


    class MyBinder extends Binder {
        MyService getService() {

            return MyService.this;
        }

    }

    public void send(String msg){

        byte[] measange=msg.getBytes();
        try {
            outStream.write(measange);
        }catch (IOException e){}




    }
        public void read(Handler handler){
            thread_run=true;
            h=handler;
            try {
               // outStream = mmSocket.getOutputStream();
                inputStream=mmSocket.getInputStream();

            } catch (IOException e){Log.d("myLog","istream "+e);}

            t=new Thread(new Runnable() {


                String buffer="";
                char b;
                int a=0;
                Message msg;

                public void run() {

                    while (thread_run) {
                        try {
                           // while(inputStream.available()==0){}
                         //   if(inputStream.available()>0) {
                             //   Log.d("myLog", "inputstream avalible=" + inputStream.available());
                            a = inputStream.read();
                             //   Log.d("myLog", "thr " + NameActivity);
                                if (NameActivity.equals("Terminal")||NameActivity.equals("Termo") ) {

                                    // a = inputStream.read();
                                    b = (char) a;
                                    buffer = Character.toString(b);
                              //      Log.d(LOG_TAG, "inputstream " + a + " " + b);

                                     msg = h.obtainMessage(1, a, -1, buffer);
                                    h.sendMessage(msg);
                                //    Log.d(LOG_TAG, "inputstream Buffer " + buffer);
                                    buffer = "";
                                }

                          //  }

// посылаем прочитанные байты главной деятельности

                        } catch (IOException e) {
                            Log.d(LOG_TAG, "inputstream error ");
                            break;
                        }

                }
                }
            });
            t.start();
        }



    public  void setNameActivity(String name){

        this.NameActivity=name;

    }
    public void onDestroyThread(){
        thread_run=false;


    }


}
